﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLDangNhap
    {
        DB_Main db = null;

        public BLDangNhap()
        {
            db = new DB_Main();
        }

        public DataSet TaiKhoan(String Account, String Pass)
        {
            return db.ExecuteQueryDataSet("select * from TaiKhoan where UserName = '" + Account + "'AND Password = '" + Pass + "'", CommandType.Text);
        }
    }
}