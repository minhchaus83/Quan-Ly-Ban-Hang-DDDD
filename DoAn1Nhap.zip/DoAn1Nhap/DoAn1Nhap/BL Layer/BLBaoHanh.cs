﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLBaoHanh
    {
        DB_Main db = null;

        public BLBaoHanh()
        {
            db = new DB_Main();
        }

        public DataSet Lay()
        {
            return db.ExecuteQueryDataSet("select * from BaoHanh", CommandType.Text);
        }

        public bool Them(string mapbh, string madt, string makh, string tgian, ref string err)
        {
            string sqlString = "Insert Into BaoHanh Values(" + "'" + mapbh + "',N'" + madt + "',N'" + makh + "',N" + tgian + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhat(string mapbh, string madt, string makh, string tgian, ref string err)
        {
            string sqlString = "Update BaoHanh Set MaDT=N'" + madt + "',MaKH=N'" + makh + "TGianBH=N'" + tgian + "' Where MaPBH='" + mapbh + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool Xoa(ref string err, string mapbh)
        {
            string sqlString = "Delete From BaoHanh Where MaPBH='" + mapbh + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
    }
}
