﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAn1Nhap
{
    public partial class frmBaoHanh : MetroFramework.Forms.MetroForm
    {
        public frmBaoHanh()
        {
            InitializeComponent();
        }

        private void frmBaoHanh_Load(object sender, EventArgs e)
        {
            this.AutoSize = true;
        }
    }
}
