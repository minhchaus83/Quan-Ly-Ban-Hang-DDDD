﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLNhapHang
    {
        DB_Main db = null;

        public BLNhapHang()
        {
            db = new DB_Main();
        }

        public DataSet LayNhapHang()
        {
            return db.ExecuteQueryDataSet("select * from NhapHang", CommandType.Text);
        }

        public bool Them(string mapn, string mancc, string manv, DateTime ngaynhap, int thanhtien, ref string err)
        {
            string sqlString = "Insert Into NhapHang Values(" + "'" + mapn + "',N'" + mancc + "',N'" + manv + "',N'" + ngaynhap + "',N'" + thanhtien + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhat(string mapn, string mancc, string manv, DateTime ngaynhap, int thanhtien, ref string err)
        {
            string sqlString = "Update NhapHang Set MaNCC=N'" + mancc + "',MaNV=N'" + manv + "',NgayNhap=N'" + ngaynhap + "',ThanhTien=N'" + thanhtien + "' Where MaPN='" + mapn + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool Xoa(ref string err, string mapn)
        {
            string sqlString = "Delete From BaoHanh Where MaPN='" + mapn + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
    }
}
