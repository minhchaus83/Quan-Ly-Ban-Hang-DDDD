﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLDienThoai
    {
        DB_Main db = null;

        public BLDienThoai()
        {
            db = new DB_Main();
        }

        public DataSet Lay()
        {
            return db.ExecuteQueryDataSet("select * from DienThoai", CommandType.Text);
        }

        public bool Them(string ma, string ten, string anh, int gia, string dvt, int soluong, string mota, string mancc, ref string err)
        {
            string sqlString = "Insert Into DienThoai Values(" + "'" + ma + "',N'" + ten + "',N'" + anh + "'" + gia + "',N'" + dvt + "',N'" + soluong  + "'" + mota + "',N'" + mancc + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhat(string ma, string ten, string anh, int gia, string dvt, int soluong, string mota, string mancc, ref string err)
        {
            string sqlString = "Update DienThoai Set TenDT=N'" + ten + "AnhDT='N" + anh + "',GiaBan=N'" + gia + "DonViTinh=N'" + dvt + "',SoLuongCon=N'" + soluong + "MoTa=N'" + mota + "',MaNCC=N'" + mancc + "' Where MaDT='" + ma + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool Xoa(ref string err, string ma)
        {
            string sqlString = "Delete From DienThoai Where MaDT='" + ma + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
    }
}
