﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLChiTiet_HDBan
    {
        DB_Main db = null;

        public BLChiTiet_HDBan()
        {
            db = new DB_Main();
        }

        public DataSet Lay()
        {
            return db.ExecuteQueryDataSet("select * from ChiTiet_HDBan", CommandType.Text);
        }

        public bool Them(string mahd, string madt, int soluong, int dongia, ref string err)
        {
            string sqlString = "Insert Into ChiTiet_HDBan Values(" + "'" + mahd + "',N'" + madt + "',N'" + soluong + "',N" + dongia + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhat(string mahd, string madt, int soluong, int dongia, ref string err)
        {
            string sqlString = "Update ChiTiet_HDBan Set MaDT=N'" + madt + "',SoLuong=N'" + soluong + "DonGia=N'" + dongia + "' Where MaHD='" + mahd + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool Xoa(ref string err, string mahd)
        {
            string sqlString = "Delete From ChiTiet_HDBan Where MaHD='" + mahd + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
    }
}
