﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;
using DoAn1Nhap.BL_Layer;

namespace DoAn1Nhap
{
    public partial class frmDangNhap : MetroFramework.Forms.MetroForm
    {
        DataTable dt = null;
        BLDangNhap dangNhap = new BLDangNhap();
        DialogResult traloi;

        public frmDangNhap()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.AutoSize = true;

            txtAccount.Focus(); // Tự trỏ đến ô txtAccount
            txtPass.PasswordChar = '*';

            // Ẩn label
            lblEmpty.Visible = false;
            lblError.Visible = false;

            // Chữ hiển thị mờ trong txtAccount và txtPass
            txtAccount.ForeColor = Color.LightGray;
            txtAccount.Text = "User Name";
            txtPass.ForeColor = Color.LightGray;
            txtPass.Text = "Password";
        }

        // Khi rời khỏi ô txtAccount nếu còn trống sẽ hiển thị lại chữ mờ ban đầu 
        private void txtLogin_Leave(object sender, EventArgs e)
        {
            if (txtAccount.Text == "")
            {
                txtAccount.Text = "User Name";
                txtAccount.ForeColor = Color.LightGray;
            }
        }

        // Khi trỏ đến sẽ xóa trống ô textbox để nhập
        private void txtLogin_Enter(object sender, EventArgs e)
        {
            if (txtAccount.Text != "")
            {
                txtAccount.ResetText();
                txtAccount.ForeColor = Color.Black;
            }
        }

        private void txtPass_Leave(object sender, EventArgs e)
        {
            if (txtPass.Text == "")
            {
                txtPass.Text = "Password";
                txtPass.ForeColor = Color.LightGray;
            }
        }

        private void txtPass_Enter(object sender, EventArgs e)
        {
            if (txtPass.Text != "")
            {
                txtPass.ResetText();
                txtPass.ForeColor = Color.Black;
            }
        }

        // Kiểm tra đăng nhập
        private void KiemTra()
        {
            // Nếu các textbox trống hoặc có các chữ ẩn như "User Name" hoặc "Password" thì sẽ hiện lblEmpty
            if (txtAccount.Text == "" || txtAccount.Text == "User Name" || txtPass.Text == "" || txtPass.Text == "Password"
               || (txtAccount.Text == "" && txtPass.Text == "") || (txtAccount.Text == "User Name" && txtPass.Text == "Password"))
            {
                lblEmpty.Visible = true;
            }

            else
            {
                dt = new DataTable();
                dt.Clear();
                DataSet ds = dangNhap.TaiKhoan(txtAccount.Text, txtPass.Text);
                dt = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    this.Hide();
                    frmWaiting frmWait = new frmWaiting();
                    frmWait.ShowDialog();
                    this.Close();
                }
                else
                {
                    lblError.Visible = true;
                    this.txtAccount.Text = "";
                    this.txtPass.Text = "";
                    this.txtAccount.Focus();
                }
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            KiemTra();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            traloi = MessageBox.Show("Bạn chắc chắn muốn thoát không?", "Trả lời", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (traloi == DialogResult.OK)
                Close();
        }
    }
}