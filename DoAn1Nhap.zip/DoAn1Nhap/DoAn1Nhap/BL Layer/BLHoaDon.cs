﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLHoaDon
    {
        DB_Main db = null;

        public BLHoaDon()
        {
            db = new DB_Main();
        }

        public DataSet Lay()
        {
            return db.ExecuteQueryDataSet("select * from HoaDon", CommandType.Text);
        }

        public bool Them(string mahd, string makh, string manv, DateTime ngayban, int thanhtien, ref string err)
        {
            string sqlString = "Insert Into HoaDon Values(" + "'" + mahd + "',N'" + makh + "',N'" + manv + "',N" + ngayban + "',N'" + thanhtien + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhat(string mahd, string makh, string manv, DateTime ngayban, int thanhtien, ref string err)
        {
            string sqlString = "Update HoaDon Set MaKH=N'" + makh + "',MaNV=N'" + manv + "NgayBan=N'" + ngayban + "ThanhTien=N'" + thanhtien + "' Where mahd='" + mahd + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool Xoa(ref string err, string mahd)
        {
            string sqlString = "Delete From HoaDon Where MaHD='" + mahd + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
    }
}
