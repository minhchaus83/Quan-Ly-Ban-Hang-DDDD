﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLNhanVien
    {
        DB_Main db = null;

        public BLNhanVien()
        {
            db = new DB_Main();
        }

        public DataSet Lay()
        {
            return db.ExecuteQueryDataSet("select * from NhanVien", CommandType.Text);
        }

        public bool Them(string manv, string hoten, DateTime ngaysinh, string gioitinh, string diachi, string sdt, string cmnd, ref string err)
        {
            string sqlString = "Insert Into NhanVien Values(" + "'" + manv + "',N'" + hoten + "',N'" + ngaysinh + "',N'" + gioitinh + "',N'" + diachi + "',N'" + sdt + "',N'" + cmnd + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhat(string manv, string hoten, DateTime ngaysinh, string gioitinh, string diachi, string sdt, string cmnd, ref string err)
        {
            string sqlString = "Update NhanVien Set HoTen=N'" + hoten + "',NgaySinh=N'" + ngaysinh + "',GioiTinh=N'" + gioitinh + "',DiaChi=N'" + diachi + "',SDT=N'" + sdt + "',CMND=N'" + cmnd  + "' Where MaNV='" + manv + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool Xoa(ref string err, string manv)
        {
            string sqlString = "Delete From BaoHanh Where MaNV='" + manv + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
    }
}
