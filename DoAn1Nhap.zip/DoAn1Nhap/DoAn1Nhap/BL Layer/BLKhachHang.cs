﻿using DoAn1Nhap.DB_Layer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn1Nhap.BL_Layer
{
    class BLKhachHang
    {
        DB_Main db = null;

        public BLKhachHang()
        {
            db = new DB_Main();
        }

        public DataSet Lay()
        {
            return db.ExecuteQueryDataSet("select * from KhachHang", CommandType.Text);
        }

        public bool Them(string makh, string ten, string diachi, string sdt, ref string err)
        {
            string sqlString = "Insert Into KhachHang Values(" + "'" + makh + "',N'" + ten + "',N'" + diachi + "',N" + sdt + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhat(string makh, string ten, string diachi, string sdt, ref string err)
        {
            string sqlString = "Update KhachHang Set TenKH=N'" + ten + "',DiaChi=N'" + diachi + "SDT=N'" + sdt + "' Where MaKH='" + makh + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool Xoa(ref string err, string makh)
        {
            string sqlString = "Delete From KhachHang Where MaKH='" + makh + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
    }
}
