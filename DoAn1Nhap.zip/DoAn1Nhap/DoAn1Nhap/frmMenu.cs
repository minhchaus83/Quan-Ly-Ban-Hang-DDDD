﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;

namespace DoAn1Nhap
{
    public partial class frmMenu : MetroFramework.Forms.MetroForm
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            DialogResult traloi = MessageBox.Show("Bạn có chắc muốn đăng xuất không?", "Trả lời", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (traloi == DialogResult.OK)
            {
                this.Hide();
                frmDangNhap frmDN = new frmDangNhap();
                frmDN.ShowDialog();
                this.Close();
            }
        }

        private void btnDienThoai_Click(object sender, EventArgs e)
        {
            frmDienThoai frmDT = new frmDienThoai();
            frmDT.ShowDialog();
        }

        private void btnNhanVien_Click(object sender, EventArgs e)
        {
            frmNhanVien frmNV = new frmNhanVien();
            frmNV.ShowDialog();
        }

        private void btnNCC_Click(object sender, EventArgs e)
        {
            frmNhaCungCap frmNCC = new frmNhaCungCap();
            frmNCC.ShowDialog();
        }

        private void btnKhachHang_Click(object sender, EventArgs e)
        {
            frmKhachHang frmKH = new frmKhachHang();
            frmKH.ShowDialog();
        }
    }
}
